<?php

echo view('landing/v_head');
echo view('landing/v_header');
// echo view('landing/v_nav');
echo view('landing/v_content');
echo view('landing/v_footer');